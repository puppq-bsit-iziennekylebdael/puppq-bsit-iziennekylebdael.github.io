/* ============================================================
   auth.js
   ------------------------------------------------------------
   Lightweight, front-end-only "authentication" for a university
   project demo. There is NO real backend or database here —
   user records are saved as plain JSON in the browser's
   localStorage under the key "izienne-users".

   ⚠️ IMPORTANT — NOT REAL SECURITY:
   Passwords are stored in plain text inside localStorage, which
   is readable by anyone with access to the browser's DevTools
   (Application → Local Storage) on the same device. This is
   fine for demonstrating *frontend logic and UX flow* in a
   classroom setting, but it must never be used as a real
   authentication system for actual user accounts. A real app
   would hash passwords server-side and never store them
   client-side at all.

   This single file is linked from BOTH login.html and
   signup.html. It detects which form is present on the page
   and wires up the matching behavior automatically.
   ============================================================ */

(function () {
  'use strict';

  const STORAGE_KEY = 'izienne-users';
  const SESSION_KEY = 'izienne-current-user';

  /* ----------------------------------------------------------
     Storage helpers
     ---------------------------------------------------------- */

  // Reads the array of saved users from localStorage (or [] if none/corrupt).
  function getUsers() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      const parsed = raw ? JSON.parse(raw) : [];
      return Array.isArray(parsed) ? parsed : [];
    } catch (e) {
      return [];
    }
  }

  // Persists the full users array back to localStorage.
  function saveUsers(users) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(users));
      return true;
    } catch (e) {
      // Most likely a quota error or localStorage disabled (e.g. private mode).
      return false;
    }
  }

  // Simple case-insensitive email match helper.
  function findUserByEmail(email) {
    const normalized = email.trim().toLowerCase();
    return getUsers().find((u) => u.email.toLowerCase() === normalized) || null;
  }

  /* ----------------------------------------------------------
     Toast / inline message UI
     ----------------------------------------------------------
     Both pages already include a #authToast container (see the
     HTML snippets). This renders a small styled banner inside
     it instead of using a native alert(), so it matches the
     site's look and feel.
     ---------------------------------------------------------- */

  function showAuthMessage(message, type) {
    // type: 'success' | 'error'
    const toast = document.getElementById('authToast');
    if (!toast) return;

    toast.textContent = message;
    toast.className = 'auth-toast auth-toast-' + (type === 'success' ? 'success' : 'error') + ' is-visible';

    // Re-trigger the entrance animation if the same message fires twice in a row.
    void toast.offsetWidth;
    toast.classList.add('is-visible');
  }

  function clearAuthMessage() {
    const toast = document.getElementById('authToast');
    if (toast) toast.classList.remove('is-visible');
  }

  /* ----------------------------------------------------------
     SIGN-UP FLOW
     ---------------------------------------------------------- */

  function initSignupForm() {
    const form = document.getElementById('signupForm');
    if (!form) return; // Not on the signup page — nothing to do.

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      clearAuthMessage();

      const firstNameEl = document.getElementById('firstName');
      const lastNameEl = document.getElementById('lastName');
      const emailEl = document.getElementById('email');
      const passwordEl = document.getElementById('password');
      const confirmEl = document.getElementById('confirmPassword');

      const firstName = firstNameEl ? firstNameEl.value.trim() : '';
      const lastName = lastNameEl ? lastNameEl.value.trim() : '';
      const fullName = (firstName + ' ' + lastName).trim();
      const email = emailEl.value.trim();
      const password = passwordEl.value;
      const confirmPassword = confirmEl ? confirmEl.value : password;

      // --- Validation ---
      if (password !== confirmPassword) {
        showAuthMessage("Passwords don't match — please double check and try again.", 'error');
        return;
      }
      if (password.length < 8) {
        showAuthMessage('Password must be at least 8 characters long.', 'error');
        return;
      }
      if (findUserByEmail(email)) {
        showAuthMessage('An account with that email already exists. Try logging in instead.', 'error');
        return;
      }

      // --- Save the new user object ---
      const users = getUsers();
      users.push({
        name: fullName || email.split('@')[0],
        email: email,
        password: password, // plain text — see security note at top of file
        createdAt: new Date().toISOString(),
      });

      if (!saveUsers(users)) {
        showAuthMessage('Could not save your account on this device/browser. Please try again.', 'error');
        return;
      }

      // --- Success: styled message + redirect to login.html ---
      showAuthMessage('🎉 Account created! Redirecting you to login...', 'success');
      form.querySelector('.btn-submit').disabled = true;

      setTimeout(function () {
        window.location.href = 'login.html';
      }, 1800);
    });
  }

  /* ----------------------------------------------------------
     LOGIN FLOW
     ---------------------------------------------------------- */

  function initLoginForm() {
    const form = document.getElementById('loginForm');
    if (!form) return; // Not on the login page — nothing to do.

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      clearAuthMessage();

      const emailEl = document.getElementById('email');
      const passwordEl = document.getElementById('password');
      const email = emailEl.value.trim();
      const password = passwordEl.value;

      const user = findUserByEmail(email);

      if (!user || user.password !== password) {
        showAuthMessage('Incorrect email or password. Please try again.', 'error');
        // A little shake animation on the card draws the eye to the error.
        const card = document.querySelector('.auth-card');
        if (card) {
          card.classList.remove('shake');
          void card.offsetWidth;
          card.classList.add('shake');
        }
        return;
      }

      // --- Success: remember the session, show message, redirect home ---
      try {
        sessionStorage.setItem(SESSION_KEY, JSON.stringify({ name: user.name, email: user.email }));
      } catch (e) {}

      showAuthMessage('✅ Welcome back, ' + (user.name || 'friend') + '! Redirecting...', 'success');
      form.querySelector('.btn-submit').disabled = true;

      setTimeout(function () {
        window.location.href = 'index.html';
      }, 1500);
    });
  }

  /* ----------------------------------------------------------
     Init on page load
     ---------------------------------------------------------- */
  document.addEventListener('DOMContentLoaded', function () {
    initSignupForm();
    initLoginForm();
  });
})();
